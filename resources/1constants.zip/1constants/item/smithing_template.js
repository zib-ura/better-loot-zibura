const smithing_template_overworld = [
    // { id: "minecraft:netherite_upgrade_smithing_template", ratio: 10 },
    { id: "minecraft:bolt_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:coast_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:dune_armor_trim_smithing_template", ratio: 10 },
    // { id: "minecraft:eye_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:flow_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:host_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:raiser_armor_trim_smithing_template", ratio: 10 },
    // { id: "minecraft:rib_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:sentry_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:shaper_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:silence_armor_trim_smithing_template", ratio: 10 },
    // { id: "minecraft:snout_armor_trim_smithing_template", ratio: 10 },
    // { id: "minecraft:spire_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:tide_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:vex_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:ward_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:wayfinder_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:wild_armor_trim_smithing_template", ratio: 10 },
    { id: "supplementaries:blast_armor_trim_smithing_template", ratio: 10 },
    // { id: "kaleidoscope_end:ender_dragon_smithing_template", ratio: 10 },
]

const smithing_template_nether = [
    { id: "minecraft:netherite_upgrade_smithing_template", ratio: 10 },
    { id: "minecraft:rib_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:snout_armor_trim_smithing_template", ratio: 10 },
]

const smithing_template_end = [
    { id: "minecraft:spire_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:eye_armor_trim_smithing_template", ratio: 10 },
    { id: "kaleidoscope_end:ender_dragon_smithing_template", ratio: 10 },
]

const smithing_template_all_dimension = [
    { id: "minecraft:netherite_upgrade_smithing_template", ratio: 10 },
    { id: "minecraft:bolt_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:coast_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:dune_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:eye_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:flow_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:host_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:raiser_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:rib_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:sentry_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:shaper_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:silence_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:snout_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:spire_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:tide_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:vex_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:ward_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:wayfinder_armor_trim_smithing_template", ratio: 10 },
    { id: "minecraft:wild_armor_trim_smithing_template", ratio: 10 },
    { id: "supplementaries:blast_armor_trim_smithing_template", ratio: 10 },
    { id: "kaleidoscope_end:ender_dragon_smithing_template", ratio: 10 },
]