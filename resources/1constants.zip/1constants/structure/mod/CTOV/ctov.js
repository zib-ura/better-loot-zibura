const loot_ctov_village_smith = [
    [village_armorer_content, 1],
    [village_fletcher_content, 1],
    [village_toolsmith_content, 1],
    [village_weaponsmith_content, 1],
];

const loot_ctov_village_bakery = [
    [village_farm_content, 1],
    [village_butcher_content, 1],
];
