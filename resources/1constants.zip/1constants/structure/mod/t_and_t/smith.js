const loot_t_And_T_village_smith = [
    [village_armorer_content, 1],
    [village_toolsmith_content, 1],
    [village_weaponsmith_content, 1],
];