const loot_trek_common_mushroom_house = [
    [village_mushroom_house_content, 2],
    [village_cartographer_content, 1],
    [village_toolsmith_content, 1],
    [village_mason_content, 1],
];