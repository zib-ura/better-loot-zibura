const basic_baking_material = [

    { id: "farm_and_charm:yeast", ratio: 25 },
    { id: "minecraft:milk_bucket", ratio: 25 },           
    { id: "minecraft:ice", ratio: 25 },           
    { reference: "lootjs:egg", ratio: 15 },
    { reference: "lootjs:egg_and_egg_block", ratio: 10 },

    { reference: "lootjs:flour", ratio: 15 },
    { reference: "lootjs:flour_and_flour_block", ratio: 10 },

    { reference: "lootjs:sugar", ratio: 15 },
    { reference: "lootjs:sugar_and_sugar_block", ratio: 10 },

    { reference: "lootjs:wheat", ratio: 15 },
    { reference: "lootjs:wheat_and_wheat_block", ratio: 10 },

    { reference: "lootjs:cheese_slice", ratio: 15 },
    { reference: "lootjs:cheese_slice_and_cheese_slice_block", ratio: 10 },

]